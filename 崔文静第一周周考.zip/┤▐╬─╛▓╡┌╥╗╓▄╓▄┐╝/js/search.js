// 搜索框
const record = document.querySelector(".list");
const search = document.querySelector(".search input");
const rem = document.querySelector(".remove");
const cancel = document.querySelector(".search p");
// input keydown事件 点击回车本地存储
search.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {
        if (search.value != "") {
            localStorage.getItem("xiu") || localStorage.setItem("xiu", "[]");
            var item = JSON.parse(localStorage.getItem("xiu"));
            var index = item.indexOf(search.value.trim());
            if (index !== -1) {
                item.splice(index, 1);
            }
            item.unshift(search.value.trim());
            var itemstr = JSON.stringify(item);
            localStorage.setItem("xiu", itemstr);
            record.innerHTML = item.map( (i) =>{
                return `
                            <li>${i}</li>
                        `
            }).join("");
            search.value = "";
        }
    }
})
// 点击删除
rem.onclick =  () =>{
    localStorage.removeItem("xiu");
    record.innerHTML = "";
}
// 点击取消 回主页面

cancel.onclick =  () =>{
    location.href = "../index.html";
}

// 外部历史记录渲染
var list = localStorage.getItem("xiu") ? JSON.parse(localStorage.getItem("xiu")) : [];
record.innerHTML = list.map( (i) =>{
    return `
                <li>${i}</li>
            `
}).join("");
// 点击删除单条数据
record.onclick =  (e) =>{
    var target = e.target;
    var arr = JSON.parse(localStorage.getItem("xiu"));
    arr.splice(arr.indexOf(target.innerHTML), 1);
    localStorage.setItem("xiu", JSON.stringify(arr));
    target.remove();
}