// 跳转
const search = document.querySelector(".search input");
search.onclick = () => {
    location.href = "./html/search.html";
}
// 中间内容滑动
const bs = new BScroll("#wrap", {
    scrollY: true,
    click: true
})
// 下拉加载
const down = document.querySelector(".top");
const list = document.querySelector(".list");
const lists = document.querySelector(".con");
const downs = document.querySelector(".bottom");
/* const myBScroll = new BScroll('#main', {
    scrollY: true,
    
    pullUpLoad: {
        threahold: 100
    }
    // pullUpLoad: true
})
myBScroll.on("pullingDown", function () {
    down.innerHTML = "加载···";
    ajax('get', './json/data.json', {
    }, function (list) {
        var data = JSON.parse(list);
        setTimeout(() => {
            down.innerHTML = "·····";
            renderBottom(data.list);
            myBScroll.finishPullDown();
            myBScroll.refresh();
        }, 2000);
    })
}) */
/* function renderBottom(data) {
    hot.innerHTML += data.map(function (val) {
        return `
                    <li>
                        <dl>
                            <dt>
                                <img src="${val.img}" />
                            </dt>
                            <dd>
                                <h2>${val.h2}</h2>
                                <p>${val.p}</p>
                                <p>
                                    <span>
                                        ${val.span}
                                    </span>
                                </p>
                                <p class="price">
                                    ￥<b>${val.price}</b>
                                    <del>z${val.prices}</del>
                                    <a href="#">${val.as}</a>
                                </p>
                            </dd>
                        </dl>
                    </li>
                `
    }).join("");
} */
// 瀑布流
class Falls {
    constructor( lists) {
        this.li = lists;
        this.con = lists.children;
        
    }
    init() {
        this.Aj();
    }
    
    Aj(){
        ajax("get", "./json/data.json", {
        },  (data) =>{
            var list = JSON.parse(data);
            this.renTwo(list.list);
        })
    }
    renTwo(data) {
        for (var i = 0; i < data.length; i++) {
            var dl = document.createElement("dl");
            dl.innerHTML += `
                        <dt>
                        <img src="${data[i].img}"/>
                    </dt>
                    <dd>
                        <h2>${data[i].h2}</h2>
                        <p>3d重手工<span>${data[i].prices}</span></p>
                    </dd>
                    
                    `
            let cons = [...this.con];
            cons.sort(function (a, b) {
                return a.offsetHeight - b.offsetHeight;
            })
            cons[0].appendChild(dl);
        }
    }
    
}
var at = new Falls( lists);
at.init();
var myBScroll = new BScroll('#main', {
    scrollY: true,
    pullUpLoad: {
        threahold: 100
    }
    // pullUpLoad: true
})
// 下拉加载
myBScroll.on("pullingUp", function () {
        downs.innerHTML = "加载···";
        ajax('get', './json/data.json', {
        }, function (list) {
            var data = JSON.parse(list);
            setTimeout(() => {
                downs.innerHTML = "·····";
                at.renTwo(data.list);
                myBScroll.finishPullUp();
                myBScroll.refresh();
            }, 2000);
        })
    })
